#!/bin/bash
for i in {1..77}
do
rm -rf file$i
done
