#!/bin/bash
for table in {2..20..2}
do
echo "Table for 2: $table"
done
