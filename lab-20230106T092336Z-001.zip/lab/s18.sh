#!/bin/bash
while true
do
echo "This is infinite loop."
sleep 10
echo " press ctrl+c to exit"
sleep 10
done
