#!/bin/bash
echo "Enter Your Name:"
read a
echo "Enter Company Name:"
read b
echo "Your Name: $a , Company Name: $b"
echo "Thank You!"

