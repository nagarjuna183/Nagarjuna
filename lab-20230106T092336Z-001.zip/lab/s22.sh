#!/bin/bash
function welcome () {
echo "welcome DevOps training $1 $2"
}
welcome 10 abc
welcome ashok riyaz

