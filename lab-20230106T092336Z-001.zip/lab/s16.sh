#!/bin/bash
for (( i=20; i>= 10; i--))
do
echo "$i"
done
