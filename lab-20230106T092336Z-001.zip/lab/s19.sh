#!/bin/bash
while :
do
echo "Infinite loop"
echo "To exit ctrl+c"
done
