#!/bin/bash
function script () {
echo "This is function script"
ls 
uptime
}
script
script
script
script
script
script
script
script
script
script
script
script
script
script
script
script

