echo "hello script4"

