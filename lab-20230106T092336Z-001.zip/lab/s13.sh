#!/bin/bash
for i in 1 2 3 4 5 6 7
do
touch file$i
done
