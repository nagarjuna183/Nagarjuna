#!/bin/bash
user=jenkins
port=8080
name=devops
