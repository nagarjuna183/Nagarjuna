#!/bin/bash

var1=Hello
var2=World
echo "$var1 $var2"
echo "hello"
