#!/bin/bash
#source s8.sh
echo "This is $user with $port"
echo "Training name $name"

