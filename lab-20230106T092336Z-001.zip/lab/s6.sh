#!/bin/bash
echo "enter your name:"
read name
echo "enter company name:"
read company
