echo "Hello script3"
bash s4.sh

