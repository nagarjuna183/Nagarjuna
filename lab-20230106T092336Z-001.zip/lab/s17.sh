i=10;
while [ $i -ge 5 ];
do
echo "Reverse order number $i"
let i--;
done
